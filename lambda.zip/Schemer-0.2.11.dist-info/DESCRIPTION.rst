Schemer allows users to declare schemas for Python dicts and lists and then validate actual dicts and lists against those schemas.


