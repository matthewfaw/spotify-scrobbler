Mongothon is a MongoDB object-document mapping API for Python, loosely based on the awesome mongoose.js library.


